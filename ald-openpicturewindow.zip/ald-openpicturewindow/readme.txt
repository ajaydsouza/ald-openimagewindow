=== Open Picture Window ===
Tags: Open Picture Window, images, open window, javascript
Contributors: Ajay D'Souza

Opens a new browser window containing the image specified using JavaScript. You have the option to choose the features as well as choose if you want it to be centered.


== Installation ==

1. Extract the entire folder ald-openpicturewindow into your plugins director, usually '/wp-content/plugins'
2. Activate the plugin on the plugin screen of WP-Admin


== Frequently Asked Questions ==

= What are the requirements for this plugin? =

1. WordPress 1.5 or above 
2. The user's browser needs to have JavaScript enabled


= Can I customize what is displayed? =

Yes, you can. Please visit http://www.ajaydsouza.com/wordpress/plugins/open-picture-window-plugin/

= Do I really need this plugin? =
If you would like to display the picture in a new window but are worried about XHTML compliance, then using JavaScript is a good solution for the same. That's where this plugin steps in.
